---
name: LinkServi Design System
colors:
  surface: '#f7f9ff'
  surface-dim: '#c1ddfb'
  surface-bright: '#f7f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#edf4ff'
  surface-container: '#e3efff'
  surface-container-high: '#d8eaff'
  surface-container-highest: '#cee5ff'
  on-surface: '#001d32'
  on-surface-variant: '#43474d'
  inverse-surface: '#16334a'
  inverse-on-surface: '#e8f2ff'
  outline: '#74777e'
  outline-variant: '#c3c6ce'
  surface-tint: '#49607c'
  primary: '#00152a'
  on-primary: '#ffffff'
  primary-container: '#102a43'
  on-primary-container: '#7a92b0'
  inverse-primary: '#b0c9e8'
  secondary: '#006c4a'
  on-secondary: '#ffffff'
  secondary-container: '#82f5c1'
  on-secondary-container: '#00714e'
  tertiary: '#280c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#481b00'
  on-tertiary-container: '#eb6905'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d1e4ff'
  primary-fixed-dim: '#b0c9e8'
  on-primary-fixed: '#011d35'
  on-primary-fixed-variant: '#314863'
  secondary-fixed: '#85f8c4'
  secondary-fixed-dim: '#68dba9'
  on-secondary-fixed: '#002114'
  on-secondary-fixed-variant: '#005137'
  tertiary-fixed: '#ffdbca'
  tertiary-fixed-dim: '#ffb690'
  on-tertiary-fixed: '#341100'
  on-tertiary-fixed-variant: '#783200'
  background: '#f7f9ff'
  on-background: '#001d32'
  surface-variant: '#cee5ff'
typography:
  h1:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  h2:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  h3:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 12px
  md: 16px
  lg: 24px
  xl: 32px
  2xl: 48px
  container-margin: 20px
  gutter: 16px
---

## Brand & Style
This design system is engineered for a dual-sided marketplace that demands professional rigor and consumer-grade accessibility. The brand personality is "The Reliable Facilitator"—authoritative enough to handle financial escrow and professional services, yet intuitive enough for daily casual use.

The visual style follows a **Corporate / Modern** aesthetic. It prioritizes clarity and efficiency, utilizing generous white space and a structured hierarchy to eliminate cognitive load. The design evokes feelings of security, technological sophistication, and logistical precision. It avoids trendy flourishes in favor of timeless, functional minimalism that scales across different user modes (Client vs. Professional).

## Colors
The palette is strategically segmented to provide instant context to the user based on their current role within the app:

*   **Deep Corporate Blue (Client Mode):** Used as the primary anchor for the consumer experience, signaling stability, trust, and institutional security.
*   **Emerald Green (Professional/Store Mode):** A distinct shift in the UI environment that signals growth, action, and the "business" side of the platform.
*   **Vibrant Orange:** Reserved strictly for high-priority alerts, promotional call-outs, and urgent status updates (e.g., "Payment Required").
*   **Neutrals:** A slate-based neutral scale is used for typography and borders to maintain a cool, professional temperature throughout the interface.

## Typography
The system utilizes **Inter** for its exceptional legibility and neutral, "Enterprise" character. The typographic scale is highly disciplined to ensure that dense service data and financial information remain scannable. 

Bold weights are used sparingly for primary headings to establish a clear information architecture. Body text defaults to a medium slate grey to reduce eye strain, while active labels and interactive elements utilize high-contrast black or the mode-specific primary color.

## Layout & Spacing
The design system employs a **Fluid Grid** model with an 8px base unit. For mobile viewports, a 4-column system is used with 20px side margins to ensure content doesn't feel cramped. On larger screens, this expands to a 12-column layout.

Spacing is used to group related concepts. For example, professional credentials and ratings are tightly grouped (8px), while distinct service categories are separated by larger vertical rhythms (32px) to provide visual breathing room and reinforce the minimalist aesthetic.

## Elevation & Depth
Depth is communicated through **Ambient Shadows** and subtle tonal layering. The system avoids heavy gradients, relying instead on a "card-on-surface" model.

*   **Level 0 (Surface):** The main background, using a very light grey or off-white.
*   **Level 1 (Cards):** Standard white cards with a soft, diffused shadow (Y: 4px, Blur: 12px, Opacity: 4%) and a 1px neutral-light stroke.
*   **Level 2 (Modals/Active):** Elements that require immediate focus use a more pronounced shadow (Y: 8px, Blur: 24px, Opacity: 8%) to appear physically closer to the user.
*   **Interactive State:** Buttons and cards may lift slightly on hover (web) or display a subtle inner glow when tapped (mobile) to provide tactile feedback.

## Shapes
The shape language is defined by a consistent **8px (0.5rem)** radius across all primary components. This "Rounded" setting strikes a balance between the "sharp" look of traditional enterprise software and the "soft" look of consumer apps. 

Containers such as large cards use the `rounded-lg` (16px) property to frame content softly, while smaller interactive elements like checkboxes or mini-tags maintain the base 4px-8px radius for precision.

## Components

### Buttons
Primary buttons use the mode-specific color (Client Blue or Professional Green) with white text. Secondary buttons utilize a subtle 1px border. The corner radius is strictly 8px.

### Search Bars
Buscadores (search bars) are prominent, featuring a white background even on colored headers, 12px internal padding, and a "soft-shadow" elevation to make them the primary focal point of the discovery phase.

### Cards
Cards are the primary container for services and products. They feature a 1px border in a very light neutral shade (#E2E8F0) and the standard 8px corner radius. Content within cards is padded by 16px.

### Form Inputs
Inputs use a clear label above the field. The border turns to the Primary color on focus, with a 2px outer glow (ring) to emphasize the active state.

### Escrow & Trust Badges
Specialized "Security" components (indicating Escrow or verified professionals) use a specific shield icon with a thin-line style and a "Safe-Blue" or "Success-Green" tint to reinforce the platform's core value of safety.

### Chips & Tags
Used for service categories or status (e.g., "Pending," "Completed"). These use a low-saturation background of the primary color with high-saturation text for readability without being distracting.