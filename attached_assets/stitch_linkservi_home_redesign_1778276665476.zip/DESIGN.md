---
name: LinkServi Deep Tech
colors:
  surface: '#0d1516'
  surface-dim: '#0d1516'
  surface-bright: '#333a3c'
  surface-container-lowest: '#080f11'
  surface-container-low: '#151d1e'
  surface-container: '#192122'
  surface-container-high: '#242b2d'
  surface-container-highest: '#2e3638'
  on-surface: '#dce4e5'
  on-surface-variant: '#bac9cc'
  inverse-surface: '#dce4e5'
  inverse-on-surface: '#2a3233'
  outline: '#849396'
  outline-variant: '#3b494c'
  surface-tint: '#00daf3'
  primary: '#c3f5ff'
  on-primary: '#00363d'
  primary-container: '#00e5ff'
  on-primary-container: '#00626e'
  inverse-primary: '#006875'
  secondary: '#d1bcff'
  on-secondary: '#3c0090'
  secondary-container: '#7000ff'
  on-secondary-container: '#ddcdff'
  tertiary: '#abffcb'
  on-tertiary: '#003920'
  tertiary-container: '#00ee98'
  on-tertiary-container: '#00673f'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#9cf0ff'
  primary-fixed-dim: '#00daf3'
  on-primary-fixed: '#001f24'
  on-primary-fixed-variant: '#004f58'
  secondary-fixed: '#e9ddff'
  secondary-fixed-dim: '#d1bcff'
  on-secondary-fixed: '#23005b'
  on-secondary-fixed-variant: '#5700c9'
  tertiary-fixed: '#52ffac'
  tertiary-fixed-dim: '#00e290'
  on-tertiary-fixed: '#002111'
  on-tertiary-fixed-variant: '#005231'
  background: '#0d1516'
  on-background: '#dce4e5'
  surface-variant: '#2e3638'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  section-gap: 80px
---

## Brand & Style

This design system establishes a premium, tech-forward marketplace identity designed to bridge the gap between service providers and modern consumers. The brand personality is efficient, secure, and luminous, prioritizing clarity within a immersive dark environment. 

The aesthetic leverages **Glassmorphism** and **High-Contrast Bold** elements. By utilizing deep-space backgrounds contrasted with vibrant, glowing interactive elements, the design system creates a sense of infinite depth and high precision. It is designed for a tech-savvy audience that values speed, reliability, and "at-a-glance" information density.

## Colors

The palette is centered around a "Dark Space" philosophy. The primary accent is an electric cyan that serves as the beacon for all critical actions and brand identity. 

- **Primary (Electric Cyan):** Used for primary buttons, active states, and brand marks.
- **Secondary (Vivid Purple):** Used for premium service categories and creative toolsets.
- **Tertiary (Teal/Mint):** Reserved for success states and logistics/transportation categories.
- **Quaternary (Amber):** Specific to employment, high-priority alerts, or ratings.
- **Background Tiers:** The foundation uses a deep navy-black (`#020817`) for the base, with slate-toned surfaces (`#0F172A`) for containers to maintain legibility without harsh contrast.

## Typography

This design system uses a dual-font strategy to balance character with utility. **Plus Jakarta Sans** provides a modern, geometric feel for headlines, making the brand feel approachable yet high-tech. **Inter** is utilized for all body copy and UI labels due to its exceptional legibility in dark mode environments.

Hierarchy is established through significant weight shifts (Bold for headers, Regular for body) and generous line heights to prevent "text crowding" against dark backgrounds. Labels and secondary metadata use increased letter spacing and uppercase styling to provide clear visual anchors within complex service listings.

## Layout & Spacing

The layout follows a **Fluid Grid** model with a standard 12-column structure for desktop and a 4-column structure for mobile. 

- **Breathing Room:** Large section gaps (80px+) are used to separate service categories, ensuring the dark UI doesn't feel claustrophobic.
- **Density:** While the layout is spacious, card grids use a tight 24px gutter to maintain a cohesive "marketplace" feel where users can browse multiple options simultaneously.
- **Mobile First:** On mobile devices, side margins shrink to 16px to maximize screen real estate for service cards, while interactive elements maintain a minimum 48px hit area.

## Elevation & Depth

Depth is achieved through **Glassmorphism** rather than traditional drop shadows. 

1. **Base Layer:** The darkest navy, acting as the "void."
2. **Surface Layer:** Translucent slate cards with a 10% - 15% opacity white overlay and a high-degree backdrop blur (20px+).
3. **Interactive Layer:** Elements in this layer feature a subtle outer glow (0px 0px 15px) using the primary cyan color at 20% opacity.
4. **Borders:** "Ghost borders" are used—1px solid strokes with 10% white opacity—to define card edges without creating heavy visual lines.

## Shapes

The shape language is consistently "Rounded" to soften the technical edge of the dark theme. 

- **Primary Cards:** Use `rounded-xl` (1.5rem / 24px) to create a friendly, containerized look.
- **Buttons & Inputs:** Use `rounded-lg` (1rem / 16px) for a modern, ergonomic feel.
- **Status Chips:** Use a pill-shape (full radius) to differentiate them from actionable buttons.
- **Iconography:** Icons should be enclosed in circular or soft-square backgrounds with 12px padding to maintain visual weight.

## Components

### Buttons
- **Primary:** Solid Electric Cyan background with black text for maximum contrast. No shadow, but a subtle cyan glow on hover.
- **Secondary:** Transparent background with a 1px Cyan border. 
- **Tertiary/Ghost:** Text only, transforming to a low-opacity cyan background on hover.

### Service Cards
- **Category Cards:** Feature a top-aligned icon, a bold headline, and a short description. Each category uses its specific accent color (Teal, Purple, or Amber) for the icon background and a subtle bottom-glow of the same hue.
- **Glass Effect:** All cards must use `backdrop-filter: blur(20px)` and a thin, semi-transparent top-border to simulate light catching the edge of glass.

### Inputs
- **Search Bar:** Large, rounded container with a magnifying glass icon. Placeholder text is a muted slate. When focused, the border transitions to a solid Electric Cyan glow.

### Status Indicators
- **Verification Badges:** Small, pill-shaped chips with a tertiary green background and a "check" icon.
- **Real-time Counters:** Uses a small "pulsing" dot next to the number to indicate live data.

### Progress & Feedbacks
- Progress bars use a gradient from Secondary Purple to Primary Cyan to indicate movement and "flow" through the service booking process.